require("dotenv").config();
const { Client, GatewayIntentBits, Collection } = require("discord.js");
const fs = require("fs");
const http = require('http');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// Carregar comandos
client.commands = new Collection();

// Mapear comandos para arquivos
const commandMap = {
  'info': 'miscrits-info',
  'days': 'miscrits-days',
  'tier_list': 'miscrits-tier-list',
  'relics_link': 'miscrits-relics'
};

const commandFiles = fs.readdirSync("./commands").filter(file => file.endsWith(".js"));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

client.once("ready", () => {
  console.log(`✅ Bot online como ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (interaction.isAutocomplete()) {
    if (interaction.commandName === "miscrits") {
      const subcommand = interaction.options.getSubcommand();
      const subcommandGroup = interaction.options.getSubcommandGroup();
      
      if (!subcommandGroup && subcommand === "info") {
        const command = client.commands.get("miscrits-info");
        if (command && command.autocomplete) {
          try {
            await command.autocomplete(interaction);
          } catch (error) {
            console.error("❌ Erro no autocomplete:", error);
          }
        }
      }
    }
    return;
  }

  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "miscrits") {
      const subcommand = interaction.options.getSubcommand();
      const subcommandGroup = interaction.options.getSubcommandGroup();
      
      let commandName;
      
      if (!subcommandGroup) {
        commandName = commandMap[subcommand];
      } else {
        const key = `${subcommandGroup}_${subcommand}`;
        commandName = commandMap[key];
      }
      
      const command = client.commands.get(commandName);
      
      if (!command) {
        console.error(`Command not found: ${commandName} for subcommand: ${subcommand}, group: ${subcommandGroup}`);
        return;
      }
      
      try {
        await command.execute(interaction);
      } catch (error) {
        console.error(error);
        const reply = { content: "❌ Ocorreu um erro ao executar esse comando!", ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(reply);
        else await interaction.reply(reply);
      }
    }
  }
});

// Servidor web para manter online
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Bot Miscrits Online!\n');
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ Servidor rodando na porta ${PORT}`);
});

client.login(process.env.BOT_TOKEN);